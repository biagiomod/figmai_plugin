import type {
  TaxonomyCategory,
  TaxonomyEntryName,
  SourceKind,
} from "@smart-detector/schema";

// Internal to the normalizer package — not exported from index.
export interface DetectionCandidate {
  candidateEntry: TaxonomyEntryName | null;
  candidateCategory: TaxonomyCategory | null;
  sourceKind: SourceKind;
  matchedSignals: string[];
  unmatchedSignals: string[];
  rationale: string;
  ambiguous: boolean;
  alternativeCandidates: TaxonomyEntryName[];
}
