import type {
  RawNode,
  DetectionNode,
  DetectionDraft,
} from "@smart-detector/schema";
import type { TaxonomyLookup } from "@smart-detector/taxonomy-bridge";
import type { DetectionCandidate } from "./internal-types.js";
import { applyHeadingRules } from "./rules/heading-rules.js";
import { applyButtonRules } from "./rules/button-rules.js";
import { applyFormRules } from "./rules/form-rules.js";
import { applyContainerRules } from "./rules/container-rules.js";

// Rule priority order — first non-null result wins.
// Form rules run before button rules to prefer "input" over "button" for
// ambiguous frame+text-child patterns.
const RULE_CHAIN = [applyFormRules, applyHeadingRules, applyButtonRules, applyContainerRules];

function classify(node: RawNode, lookup: TaxonomyLookup): DetectionCandidate {
  for (const rule of RULE_CHAIN) {
    const result = rule(node, lookup);
    if (result !== null) {
      // Rules often hardcode unmatchedSignals:[]. Fill in all signals not
      // in matchedSignals so the inspector shows the full evidence set.
      if (result.unmatchedSignals.length === 0) {
        const matchedSet = new Set(result.matchedSignals);
        result.unmatchedSignals = node.signals.filter(s => !matchedSet.has(s));
      }
      return result;
    }
  }
  // No rule matched — return explicit null candidate
  return {
    candidateEntry: null,
    candidateCategory: null,
    sourceKind: "blank",
    matchedSignals: [],
    unmatchedSignals: node.signals,
    rationale: `No rule matched. type:${node.rawKind}, name:"${node.rawName ?? ""}". Signals: [${node.signals.slice(0, 6).join(", ")}]`,
    ambiguous: false,
    alternativeCandidates: [],
  };
}

function normalizeNode(node: RawNode, lookup: TaxonomyLookup): DetectionNode {
  const candidate = classify(node, lookup);
  return {
    id: node.id,
    sourceType: node.sourceType,
    sourcePath: node.sourcePath,
    candidateEntry: candidate.candidateEntry,
    candidateCategory: candidate.candidateCategory,
    candidateKindFamily: null,
    sourceKind: candidate.sourceKind,
    certainty: "unknown",
    reviewState: "unresolved",
    rationale: candidate.rationale,
    matchedSignals: candidate.matchedSignals,
    unmatchedSignals: candidate.unmatchedSignals,
    ambiguous: candidate.ambiguous,
    alternativeCandidates: candidate.alternativeCandidates,
    metadata: { ...node.metadata, rawName: node.rawName, textContent: node.textContent },
    children: node.children.map((child) => normalizeNode(child, lookup)),
  };
}

export function normalize(root: RawNode, lookup: TaxonomyLookup): DetectionDraft {
  return {
    version: "1",
    sourceType: root.sourceType,
    sourceRef: root.id,
    detectedAt: new Date().toISOString(),
    root: normalizeNode(root, lookup),
  };
}
