import type { RawNode } from "@smart-detector/schema";
import type { TaxonomyLookup } from "@smart-detector/taxonomy-bridge";
import type { DetectionCandidate } from "../internal-types.js";

// Detect: button, icon-button, link
export function applyButtonRules(
  node: RawNode,
  _lookup: TaxonomyLookup
): DetectionCandidate | null {
  const sig = new Set(node.signals);
  const isFrame = sig.has("type:FRAME") || sig.has("type:COMPONENT") || sig.has("type:INSTANCE");
  const isText = sig.has("type:TEXT");
  const w = typeof node.metadata["width"] === "number" ? node.metadata["width"] : 0;
  const h = typeof node.metadata["height"] === "number" ? node.metadata["height"] : 0;
  const nameHint = node.rawName?.toLowerCase() ?? "";

  // ── Link (text node) ──────────────────────────────────────────────────────
  if (isText && /link|url|anchor|cta/.test(nameHint)) {
    return {
      candidateEntry: "link",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: ["type:TEXT", "name-hint:link"],
      unmatchedSignals: [],
      rationale: `TEXT node "${node.rawName}" name matches link pattern.`,
      ambiguous: false,
      alternativeCandidates: ["text"],
    };
  }

  if (!isFrame) return null;

  const hasTextChild = sig.has("has:text-child");
  const hasSolidFill = sig.has("fill:solid");
  const hasCornerRadius = sig.has("has:corner-radius");
  const hasStroke = sig.has("has:stroke");
  const isSquarish = w > 0 && h > 0 && Math.abs(w / h - 1) < 0.3;
  const isSmall = w <= 56 && h <= 56;

  // ── Button (explicit name) ────────────────────────────────────────────────
  if (sig.has("name-hint:button")) {
    const matched = ["name-hint:button", "type:FRAME/COMPONENT/INSTANCE"];
    return {
      candidateEntry: "button",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: matched,
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" layer name matches button pattern. w:${w} h:${h}.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Icon button (small square frame, no text child or with icon child) ────
  if (isSmall && isSquarish && (sig.has("name-hint:icon") || !hasTextChild)) {
    if (hasSolidFill || hasCornerRadius || hasStroke) {
      return {
        candidateEntry: "icon-button",
        candidateCategory: "Primitives",
        sourceKind: "inferred",
        matchedSignals: ["type:FRAME", "shape:square", "size:small", hasSolidFill ? "fill:solid" : "has:stroke"],
        unmatchedSignals: [],
        rationale: `Small square frame (${w}×${h}px) with fill/stroke inferred as icon-button.`,
        ambiguous: true,
        alternativeCandidates: ["button", "icon"],
      };
    }
  }

  // ── Button (structural: frame with text + fill or stroke + reasonable size) ─
  if (hasTextChild && (hasSolidFill || hasStroke) && h >= 28 && h <= 64 && w <= 400) {
    const matched = ["has:text-child", hasSolidFill ? "fill:solid" : "has:stroke"];
    if (hasCornerRadius) matched.push("has:corner-radius");
    return {
      candidateEntry: "button",
      candidateCategory: "Primitives",
      sourceKind: "inferred",
      matchedSignals: matched,
      unmatchedSignals: [],
      rationale: `Frame with text child, ${hasSolidFill ? "solid fill" : "stroke"}, h:${h}px — inferred as button.`,
      ambiguous: !sig.has("fill:solid"),
      alternativeCandidates: ["input"],
    };
  }

  return null;
}
