import type { RawNode } from "@smart-detector/schema";
import type { TaxonomyLookup } from "@smart-detector/taxonomy-bridge";
import type { DetectionCandidate } from "../internal-types.js";

// Detect: heading, text, label, helper-text
export function applyHeadingRules(
  node: RawNode,
  _lookup: TaxonomyLookup
): DetectionCandidate | null {
  const sig = new Set(node.signals);
  const isText = sig.has("type:TEXT");
  if (!isText) return null;

  const style = node.metadata["style"] as Record<string, unknown> | undefined;
  const fontSize = typeof style?.["fontSize"] === "number" ? style["fontSize"] : 14;
  const fontWeight = typeof style?.["fontWeight"] === "number" ? style["fontWeight"] : 400;
  const fontFamily = typeof style?.["fontFamily"] === "string" ? style["fontFamily"] : undefined;
  const fontStyleStr = typeof style?.["fontStyle"] === "string" ? style["fontStyle"] : undefined;
  const nameHint = node.rawName?.toLowerCase() ?? "";

  const matched: string[] = [];
  const unmatched: string[] = [];

  // ── Heading ──────────────────────────────────────────────────────────────
  if (sig.has("name-hint:heading") || fontSize >= 24 || (fontSize >= 18 && fontWeight >= 600)) {
    if (sig.has("name-hint:heading")) matched.push("name-hint:heading");
    if (fontSize >= 24) matched.push("text:large");
    if (fontWeight >= 600) matched.push("text:bold");
    const rationale = [
      "TEXT node detected as heading.",
      fontSize >= 24 ? `fontSize ${fontSize}px ≥ 24` : null,
      fontWeight >= 600 ? `fontWeight ${fontWeight} ≥ 600` : null,
      fontFamily ? `fontFamily: ${fontFamily}` : null,
      fontStyleStr ? `fontStyle: ${fontStyleStr}` : null,
    ].filter(Boolean).join(". ");
    return {
      candidateEntry: "heading",
      candidateCategory: "Primitives",
      sourceKind: sig.has("name-hint:heading") ? "extracted" : "inferred",
      matchedSignals: matched,
      unmatchedSignals: unmatched,
      rationale,
      ambiguous: false,
      alternativeCandidates: ["text"],
    };
  }

  // ── Label ────────────────────────────────────────────────────────────────
  if (
    sig.has("name-hint:label") ||
    /label|caption/.test(nameHint) ||
    (fontSize <= 12 && fontWeight < 600)
  ) {
    matched.push("type:TEXT");
    if (sig.has("name-hint:label")) matched.push("name-hint:label");
    const rationale = [
      "TEXT node detected as label.",
      fontSize <= 12 ? `fontSize ${fontSize}px ≤ 12` : null,
      fontFamily ? `fontFamily: ${fontFamily}` : null,
    ].filter(Boolean).join(". ");
    return {
      candidateEntry: "label",
      candidateCategory: "Primitives",
      sourceKind: sig.has("name-hint:label") ? "extracted" : "inferred",
      matchedSignals: matched,
      unmatchedSignals: unmatched,
      rationale,
      ambiguous: false,
      alternativeCandidates: ["helper-text"],
    };
  }

  // ── Helper text ───────────────────────────────────────────────────────────
  if (/helper|hint|description|caption|subtitle|meta/.test(nameHint)) {
    return {
      candidateEntry: "helper-text",
      candidateCategory: "Primitives",
      sourceKind: "inferred",
      matchedSignals: ["type:TEXT", "name-hint(helper/hint pattern)"],
      unmatchedSignals: [],
      rationale: `TEXT node name "${node.rawName}" matches helper/hint pattern.`,
      ambiguous: false,
      alternativeCandidates: ["label"],
    };
  }

  // ── Generic text ─────────────────────────────────────────────────────────
  if (sig.has("has:text-content")) {
    matched.push("type:TEXT", "has:text-content");
    const rationale = [
      "TEXT node detected as body text.",
      `fontSize: ${fontSize}px`,
      fontFamily ? `fontFamily: ${fontFamily}` : null,
      fontStyleStr ? `fontStyle: ${fontStyleStr}` : null,
    ].filter(Boolean).join(". ");
    return {
      candidateEntry: "text",
      candidateCategory: "Primitives",
      sourceKind: "inferred",
      matchedSignals: matched,
      unmatchedSignals: unmatched,
      rationale,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  return null;
}
