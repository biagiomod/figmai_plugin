import type { RawNode } from "@smart-detector/schema";
import type { TaxonomyLookup } from "@smart-detector/taxonomy-bridge";
import type { DetectionCandidate } from "../internal-types.js";

// Detect: card, list, table, modal-dialog, drawer, popover, tooltip,
//         menu, accordion, tabs, alert-banner, toast, pagination,
//         header-nav, side-nav, form, section, divider, badge, icon, image, avatar
export function applyContainerRules(
  node: RawNode,
  _lookup: TaxonomyLookup
): DetectionCandidate | null {
  const sig = new Set(node.signals);
  const isFrame = sig.has("type:FRAME") || sig.has("type:COMPONENT") || sig.has("type:INSTANCE");
  const isVector = sig.has("type:VECTOR") || sig.has("type:BOOLEAN_OPERATION") || sig.has("type:ELLIPSE") || sig.has("type:STAR") || sig.has("type:POLYGON");
  const nameHint = node.rawName?.toLowerCase() ?? "";
  const w = typeof node.metadata["width"] === "number" ? node.metadata["width"] : 0;
  const h = typeof node.metadata["height"] === "number" ? node.metadata["height"] : 0;

  // ── Divider ───────────────────────────────────────────────────────────────
  if (sig.has("name-hint:divider") || /divider|separator|rule|line/.test(nameHint)) {
    const isDividerShape = (w > h * 4) || (h > w * 4);
    return {
      candidateEntry: "divider",
      candidateCategory: "Primitives",
      sourceKind: isDividerShape || sig.has("name-hint:divider") ? "extracted" : "inferred",
      matchedSignals: [sig.has("name-hint:divider") ? "name-hint:divider" : "shape:line"],
      unmatchedSignals: [],
      rationale: `Node "${node.rawName}" detected as divider. ${w}×${h}px.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Badge / Tag / Chip ───────────────────────────────────────────────────
  if (sig.has("name-hint:badge") || /badge|tag|chip|pill/.test(nameHint)) {
    return {
      candidateEntry: "badge",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:badge"],
      unmatchedSignals: [],
      rationale: `Node "${node.rawName}" matches badge/tag/chip pattern.`,
      ambiguous: false,
      alternativeCandidates: ["label"],
    };
  }

  // ── Icon (vector or small square frame named "icon") ──────────────────────
  if (
    sig.has("name-hint:icon") ||
    isVector ||
    (isFrame && w <= 48 && h <= 48 && sig.has("shape:square") && !sig.has("has:text-child"))
  ) {
    return {
      candidateEntry: "icon",
      candidateCategory: "Primitives",
      sourceKind: sig.has("name-hint:icon") || isVector ? "extracted" : "inferred",
      matchedSignals: [
        isVector ? "type:VECTOR" : "type:FRAME",
        sig.has("name-hint:icon") ? "name-hint:icon" : "shape:square",
        w <= 48 ? "size:small" : "",
      ].filter(Boolean),
      unmatchedSignals: [],
      rationale: `${isVector ? "Vector" : "Frame"} node "${node.rawName}" detected as icon. ${w}×${h}px.`,
      ambiguous: !sig.has("name-hint:icon"),
      alternativeCandidates: isFrame ? ["image"] : [],
    };
  }

  // ── Image / Avatar ────────────────────────────────────────────────────────
  if (sig.has("has:image-fill") || sig.has("name-hint:image") || /avatar|photo|thumbnail/.test(nameHint)) {
    const entry = /avatar/.test(nameHint) ? "avatar" : "image";
    return {
      candidateEntry: entry,
      candidateCategory: "Primitives",
      sourceKind: sig.has("has:image-fill") ? "extracted" : "inferred",
      matchedSignals: [sig.has("has:image-fill") ? "has:image-fill" : "name-hint:image"],
      unmatchedSignals: [],
      rationale: `Node "${node.rawName}" detected as ${entry}.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  if (!isFrame) return null;

  // ── Alert / Toast / Notification ─────────────────────────────────────────
  if (sig.has("name-hint:alert") || /alert|banner|notification/.test(nameHint)) {
    return {
      candidateEntry: "alert-banner",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:alert"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches alert/banner pattern.`,
      ambiguous: false,
      alternativeCandidates: ["toast"],
    };
  }
  if (/toast|snackbar/.test(nameHint)) {
    return {
      candidateEntry: "toast",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint(toast)"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches toast/snackbar pattern.`,
      ambiguous: false,
      alternativeCandidates: ["alert-banner"],
    };
  }

  // ── Tooltip ───────────────────────────────────────────────────────────────
  if (sig.has("name-hint:tooltip") || /tooltip|tip/.test(nameHint)) {
    return {
      candidateEntry: "tooltip",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:tooltip"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches tooltip pattern.`,
      ambiguous: false,
      alternativeCandidates: ["popover"],
    };
  }

  // ── Popover / Menu ────────────────────────────────────────────────────────
  if (/popover|dropdown.?menu|context.?menu/.test(nameHint)) {
    return {
      candidateEntry: "popover",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint(popover/menu)"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches popover/menu pattern.`,
      ambiguous: false,
      alternativeCandidates: ["menu"],
    };
  }
  if (/^menu$|menu.?item|menu.?list/.test(nameHint)) {
    return {
      candidateEntry: "menu",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint(menu)"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches menu pattern.`,
      ambiguous: false,
      alternativeCandidates: ["list"],
    };
  }

  // ── Modal / Dialog ────────────────────────────────────────────────────────
  if (sig.has("name-hint:modal") || /modal|dialog|overlay/.test(nameHint)) {
    return {
      candidateEntry: "modal-dialog",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:modal"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches modal/dialog pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Drawer / Sidebar ──────────────────────────────────────────────────────
  if (sig.has("name-hint:drawer") || /drawer|sidebar|side.?panel/.test(nameHint)) {
    return {
      candidateEntry: "drawer",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:drawer"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches drawer/sidebar pattern.`,
      ambiguous: false,
      alternativeCandidates: ["side-nav"],
    };
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  if (sig.has("name-hint:navigation") || /nav(bar|igation)?$/.test(nameHint)) {
    const isSide = /side|left|right/.test(nameHint) || (h > w);
    return {
      candidateEntry: isSide ? "side-nav" : "header-nav",
      candidateCategory: "Compositions",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:navigation"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches ${isSide ? "side" : "header"} navigation pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Tabs ──────────────────────────────────────────────────────────────────
  if (/^tabs?$|tab.?bar|tab.?group/.test(nameHint)) {
    return {
      candidateEntry: "tabs",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint(tabs)"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches tabs pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Accordion ─────────────────────────────────────────────────────────────
  if (/accordion|expander|collapsible/.test(nameHint)) {
    return {
      candidateEntry: "accordion",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint(accordion)"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches accordion pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Pagination ────────────────────────────────────────────────────────────
  if (/pagination|pager/.test(nameHint)) {
    return {
      candidateEntry: "pagination",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint(pagination)"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches pagination pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Spinner / Loader ──────────────────────────────────────────────────────
  if (/spinner|loader|loading|progress/.test(nameHint)) {
    return {
      candidateEntry: "spinner",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: ["name-hint(spinner)"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches spinner/loader pattern.`,
      ambiguous: false,
      alternativeCandidates: ["progress"],
    };
  }

  // ── Table ─────────────────────────────────────────────────────────────────
  if (sig.has("name-hint:table") || /^table$/.test(nameHint)) {
    return {
      candidateEntry: "table",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:table"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches table pattern.`,
      ambiguous: false,
      alternativeCandidates: ["list"],
    };
  }

  // ── List ──────────────────────────────────────────────────────────────────
  if (sig.has("name-hint:list") || /^list$|list.?item|list.?view/.test(nameHint)) {
    return {
      candidateEntry: "list",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:list"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches list pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Card ──────────────────────────────────────────────────────────────────
  if (sig.has("name-hint:card") || /^card$/.test(nameHint)) {
    return {
      candidateEntry: "card",
      candidateCategory: "Containers",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:card"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches card pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Form (structural: frame with multiple input-like children) ─────────────
  if (/^form$|form.?group|form.?section/.test(nameHint)) {
    return {
      candidateEntry: "form",
      candidateCategory: "Compositions",
      sourceKind: "extracted",
      matchedSignals: ["name-hint(form)"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" matches form pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  return null;
}
