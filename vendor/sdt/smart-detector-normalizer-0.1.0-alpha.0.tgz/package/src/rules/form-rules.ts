import type { RawNode } from "@smart-detector/schema";
import type { TaxonomyLookup } from "@smart-detector/taxonomy-bridge";
import type { DetectionCandidate } from "../internal-types.js";

// Detect: input, textarea, select, checkbox, radio, switch, label, helper-text
export function applyFormRules(
  node: RawNode,
  _lookup: TaxonomyLookup
): DetectionCandidate | null {
  const sig = new Set(node.signals);
  const isFrame = sig.has("type:FRAME") || sig.has("type:COMPONENT") || sig.has("type:INSTANCE");
  const isText = sig.has("type:TEXT");
  const nameHint = node.rawName?.toLowerCase() ?? "";
  const w = typeof node.metadata["width"] === "number" ? node.metadata["width"] : 0;
  const h = typeof node.metadata["height"] === "number" ? node.metadata["height"] : 0;

  // ── Checkbox ──────────────────────────────────────────────────────────────
  if (sig.has("name-hint:checkbox") || /checkbox|check.?box/.test(nameHint)) {
    return {
      candidateEntry: "checkbox",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:checkbox"],
      unmatchedSignals: [],
      rationale: `Node "${node.rawName}" matches checkbox pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Radio ─────────────────────────────────────────────────────────────────
  if (sig.has("name-hint:radio") || /radio.?button|radio.?group/.test(nameHint)) {
    return {
      candidateEntry: "radio",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:radio"],
      unmatchedSignals: [],
      rationale: `Node "${node.rawName}" matches radio pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Switch / Toggle ───────────────────────────────────────────────────────
  if (sig.has("name-hint:toggle") || /toggle|switch/.test(nameHint)) {
    return {
      candidateEntry: "switch",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:toggle"],
      unmatchedSignals: [],
      rationale: `Node "${node.rawName}" matches switch/toggle pattern.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Select / Dropdown ─────────────────────────────────────────────────────
  if (sig.has("name-hint:select") || /select|dropdown|drop.?down/.test(nameHint)) {
    return {
      candidateEntry: "select",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: ["name-hint:select"],
      unmatchedSignals: [],
      rationale: `Node "${node.rawName}" matches select/dropdown pattern.`,
      ambiguous: false,
      alternativeCandidates: ["input"],
    };
  }

  // ── Label (text node) ─────────────────────────────────────────────────────
  if (isText && (sig.has("name-hint:label") || /^label$/.test(nameHint))) {
    return {
      candidateEntry: "label",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: ["type:TEXT", "name-hint:label"],
      unmatchedSignals: [],
      rationale: `TEXT node "${node.rawName}" is a form label.`,
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Helper text (text node) ───────────────────────────────────────────────
  if (isText && /helper|hint|error.?text|caption|supporting/.test(nameHint)) {
    return {
      candidateEntry: "helper-text",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: ["type:TEXT", "name-hint(helper pattern)"],
      unmatchedSignals: [],
      rationale: `TEXT node "${node.rawName}" matches helper-text pattern.`,
      ambiguous: false,
      alternativeCandidates: ["label"],
    };
  }

  if (!isFrame) return null;

  // ── Textarea ──────────────────────────────────────────────────────────────
  if (
    /textarea|text.?area|multiline|multi.?line/.test(nameHint) ||
    (sig.has("name-hint:input") && h > 80)
  ) {
    return {
      candidateEntry: "textarea",
      candidateCategory: "Primitives",
      sourceKind: /textarea|text.?area/.test(nameHint) ? "extracted" : "inferred",
      matchedSignals: ["type:FRAME", h > 80 ? "size:tall" : "name-hint:input"],
      unmatchedSignals: [],
      rationale: `Frame "${node.rawName}" detected as textarea. h:${h}px.`,
      ambiguous: false,
      alternativeCandidates: ["input"],
    };
  }

  // ── Input (explicit name) ─────────────────────────────────────────────────
  if (sig.has("name-hint:input") || /^input$|input.?field|text.?field|form.?field/.test(nameHint)) {
    const matched = ["name-hint:input"];
    if (sig.has("has:text-child")) matched.push("has:text-child");
    if (sig.has("has:stroke")) matched.push("has:stroke");
    if (sig.has("has:padding")) matched.push("has:padding");
    const style = node.metadata["style"] as Record<string, unknown> | undefined;
    const fontFamily = typeof style?.["fontFamily"] === "string" ? style["fontFamily"] : undefined;
    return {
      candidateEntry: "input",
      candidateCategory: "Primitives",
      sourceKind: "extracted",
      matchedSignals: matched,
      unmatchedSignals: [],
      rationale: [
        `Frame "${node.rawName}" layer name matches input pattern.`,
        `Dimensions: ${w}×${h}px.`,
        fontFamily ? `fontFamily: ${fontFamily}` : null,
        sig.has("has:padding") ? "Has padding (auto-layout)." : null,
      ].filter(Boolean).join(" "),
      ambiguous: false,
      alternativeCandidates: [],
    };
  }

  // ── Input (structural: frame with text child + border/stroke, typical input height) ─
  if (
    sig.has("has:text-child") &&
    (sig.has("has:stroke") || sig.has("fill:transparent")) &&
    h >= 32 && h <= 72 && w >= 80
  ) {
    const matched = ["has:text-child", "size:input-height"];
    if (sig.has("has:stroke")) matched.push("has:stroke");
    if (sig.has("has:padding")) matched.push("has:padding");
    if (sig.has("fill:transparent")) matched.push("fill:transparent");
    return {
      candidateEntry: "input",
      candidateCategory: "Primitives",
      sourceKind: "inferred",
      matchedSignals: matched,
      unmatchedSignals: [],
      rationale: `Frame with text child, ${sig.has("has:stroke") ? "stroke border" : "transparent fill"}, h:${h}px w:${w}px — inferred as input field.`,
      ambiguous: true,
      alternativeCandidates: ["button", "select"],
    };
  }

  return null;
}
