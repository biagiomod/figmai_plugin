// ── Catalog input ─────────────────────────────────────────────────────────────

export type VariableResolvedType = "COLOR" | "FLOAT" | "STRING" | "BOOLEAN";

export interface VariableCatalogSnapshot {
  collections: VariableCollectionInfo[];
  variables: VariableInfo[];
}

export interface VariableCollectionInfo {
  id: string;
  name: string;
  modes: Array<{ modeId: string; name: string }>;
  defaultModeId: string;
  remote?: boolean;
  hiddenFromPublishing?: boolean;
}

export interface VariableInfo {
  id: string;
  name: string;                                   // e.g. "color/brand/primary"
  collectionId: string;
  resolvedType: VariableResolvedType;
  scopes: string[];                               // Figma scope strings, e.g. "ALL_FILLS"
  valuesByMode: Record<string, VariableValue>;
  codeSyntax?: Record<string, string>;
  remote?: boolean;
  deleted?: boolean;
  description?: string;
}

export type VariableValue =
  | { type: "COLOR"; r: number; g: number; b: number; a: number }
  | { type: "FLOAT"; value: number }
  | { type: "STRING"; value: string }
  | { type: "BOOLEAN"; value: boolean }
  | { type: "ALIAS"; variableId: string };

// ── Audit output ──────────────────────────────────────────────────────────────

export type FindingKind =
  | "unbound-color"
  | "unbound-typography"     // reserved; not emitted this pass
  | "orphaned-binding"
  | "mode-incomplete"
  | "mode-mismatch";         // reserved; not emitted this pass

export type FindingSeverity = "info" | "warn" | "error";

export interface TokenAuditFinding {
  id: string;                // stable: `${nodeId}:${field}:${kind}`
  kind: FindingKind;
  severity: FindingSeverity;
  nodeId: string;
  nodeName?: string;
  field: string;             // e.g. "fills[0]", "boundVariables.fills[0]"
  message: string;
  reasons: string[];
  suggestions: SuggestedVariable[];
  autoFix?: FixIntent;
  modeCoverage?: ModeCoverage;
}

export interface SuggestedVariable {
  variableId: string;
  collectionId: string;
  variableName: string;
  score: number;             // deterministic; higher = better
  confidence: "high" | "medium" | "low";
  reasons: string[];
  modeCoverage: ModeCoverage;
}

export interface ModeCoverage {
  ready: boolean;
  collectionId: string;
  missingModeIds: string[];
  requiredModeIds: string[];
}

export type FixIntentKind =
  | "bind-paint-variable"
  | "bind-text-variable"
  | "bind-text-range-variable"
  | "set-explicit-mode";

export interface FixIntent {
  kind: FixIntentKind;
  nodeId: string;
  field: string;
  variableId?: string;
  collectionId?: string;
  modeId?: string;
  safe: boolean;
  requiresConfirmation: boolean;
  skipReason?: string;
}

export interface TokenAuditReport {
  version: "1";
  sourceRef: string;                 // root node id or caller-supplied
  auditedAt: string;                 // ISO 8601
  findings: TokenAuditFinding[];
  summary: TokenAuditSummary;
}

export interface TokenAuditSummary {
  total: number;
  byKind: Record<FindingKind, number>;
  bySeverity: Record<FindingSeverity, number>;
}
