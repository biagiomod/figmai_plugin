export type ReviewState =
  | "accepted"      // certainty = "exact" AND ambiguous = false
  | "needs-review"  // certainty = "inferred" OR "weak" OR ambiguous = true
  | "unresolved";   // certainty = "unknown" OR candidateEntry = null
