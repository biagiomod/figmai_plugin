export type CertaintyLevel =
  | "exact"      // strong structural match, unambiguous
  | "inferred"   // reasonable match derived from context clues
  | "weak"       // plausible but not confident
  | "unknown";   // no match found — do not guess

export type SourceKind =
  | "extracted"  // directly readable: HTML tag name, ARIA role, Figma node type
  | "inferred"   // derived from context: class names, sibling structure, Figma layer name
  | "blank";     // no usable signals found
