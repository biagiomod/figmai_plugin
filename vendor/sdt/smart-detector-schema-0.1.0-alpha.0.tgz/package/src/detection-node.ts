import type { TaxonomyCategory, TaxonomyEntryName } from "@smart-detector/taxonomy-contract";
import type { CertaintyLevel, SourceKind } from "./confidence.js";
import type { ReviewState } from "./review-state.js";

export interface DetectionNode {
  id: string;
  sourceType: "figma" | "html";
  sourcePath: string;

  // Classification — set by normalizer
  candidateEntry: TaxonomyEntryName | null;   // null is valid and expected when no match
  candidateCategory: TaxonomyCategory | null;
  candidateKindFamily?: string | null;         // reserved for future grouping; v1: always null

  // Provenance — set by normalizer
  sourceKind: SourceKind;

  // ── Certainty ──────────────────────────────────────────────────────────────
  // certainty is a four-value string union set by the scorer.
  // It describes confidence in the BEST candidate match:
  //   "exact"    — strong structural match, unambiguous
  //   "inferred" — reasonable match derived from context clues
  //   "weak"     — plausible but not confident
  //   "unknown"  — no match found; candidateEntry will be null
  //
  // Consumers: use certainty for confidence thresholds.
  // certainty is NOT a superset of ambiguous — they are orthogonal.
  certainty: CertaintyLevel;

  // Review — set by reviewer
  reviewState: ReviewState;

  // Evidence — set by normalizer
  rationale: string;                           // required; never empty
  matchedSignals: string[];
  unmatchedSignals: string[];

  // ── Ambiguity ──────────────────────────────────────────────────────────────
  // ambiguous is a boolean set by the normalizer. It means "multiple taxonomy
  // entries were plausible and none dominated." A node can be:
  //   certainty="inferred", ambiguous=true  → best guess, but close call
  //   certainty="exact",    ambiguous=false → unambiguous match (→ "accepted")
  //
  // alternativeCandidates lists the other plausible entries when ambiguous=true.
  // Consumers: show ambiguous nodes in a review queue; do not treat ambiguous
  // as a CertaintyLevel value — it is not part of that union.
  ambiguous: boolean;
  alternativeCandidates: TaxonomyEntryName[];

  // Raw data passthrough — all source properties preserved for display and export
  metadata: Record<string, unknown>;

  children: DetectionNode[];
}
