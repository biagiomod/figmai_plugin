import type { DetectionNode } from "./detection-node.js";

export interface DetectionTree {
  version: "1";
  sourceType: "figma" | "html";
  sourceRef: string;       // Figma node ID or input file path
  detectedAt: string;      // ISO 8601 timestamp
  root: DetectionNode;
  summary: DetectionSummary;
}

// DetectionSummary is a pipeline-final aggregate.
// Computed by reviewer/summarizer. NOT present in intermediate pipeline stages.
export interface DetectionSummary {
  total: number;
  exact: number;
  inferred: number;
  weak: number;
  unknown: number;
  ambiguous: number;
  accepted: number;
  needsReview: number;
  unresolved: number;
}

// DetectionDraft is the intermediate pipeline type.
// Used by normalizer (output) and scorer (input and output).
// reviewer is the first stage that returns a complete DetectionTree with summary.
export type DetectionDraft = Omit<DetectionTree, "summary">;
