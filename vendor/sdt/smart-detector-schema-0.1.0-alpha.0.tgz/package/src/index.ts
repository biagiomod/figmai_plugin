// Re-export taxonomy-contract types so downstream packages only need @smart-detector/schema.
export type { TaxonomyCategory, TaxonomyEntryName, TaxonomyEntryRef } from "@smart-detector/taxonomy-contract";

export type { CertaintyLevel, SourceKind } from "./confidence.js";
export type { ReviewState } from "./review-state.js";
export type { RawNode } from "./raw-node.js";
export type { DetectionNode } from "./detection-node.js";
export type { DetectionTree, DetectionSummary, DetectionDraft } from "./detection-tree.js";
