export interface RawNode {
  id: string;
  sourceType: "figma" | "html";
  sourcePath: string;                       // CSS selector or Figma node path

  rawKind: string;                          // "FRAME", "TEXT", "div", "button", etc.
  rawName?: string;                         // Figma layer name or HTML id attribute
  textContent?: string;                     // visible text content if present
  role?: string;                            // ARIA role or Figma role property
  classNames?: string[];                    // HTML class list (absent for Figma)
  signals: string[];                        // normalized evidence strings collected by detector

  attributes: Record<string, string>;       // HTML attributes or Figma string properties
  metadata: Record<string, unknown>;        // anything else worth preserving

  children: RawNode[];
}
