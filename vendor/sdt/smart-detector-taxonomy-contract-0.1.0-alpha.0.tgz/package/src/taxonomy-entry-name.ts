import type { TaxonomyCategory } from "./taxonomy-category.js";

// TaxonomyEntryName is a string alias. At runtime, valid values are constrained
// to known entries in TAXONOMY_REGISTRY via TaxonomyLookup. Free-form strings are invalid.
export type TaxonomyEntryName = string;

export interface TaxonomyEntryRef {
  name: TaxonomyEntryName;    // e.g. "button", "hero", "modal-dialog"
  category: TaxonomyCategory;
  description: string;
}
