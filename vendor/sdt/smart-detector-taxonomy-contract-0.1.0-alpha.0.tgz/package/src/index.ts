export type { TaxonomyCategory } from "./taxonomy-category.js";
export type { TaxonomyEntryName, TaxonomyEntryRef } from "./taxonomy-entry-name.js";
