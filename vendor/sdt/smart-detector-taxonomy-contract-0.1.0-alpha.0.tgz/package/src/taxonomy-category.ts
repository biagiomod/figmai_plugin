export type TaxonomyCategory =
  | "Foundations"
  | "Primitives"
  | "Containers"
  | "Compositions";
