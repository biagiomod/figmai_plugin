import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { traverseFigmaNode } from "./figma-traverser.ts";

const minimalFrame = {
  id: "1:1", name: "Card", type: "FRAME",
  x: 0, y: 0, width: 320, height: 200,
  fills: [{ type: "SOLID", color: { r: 1, g: 1, b: 1, a: 1 } }],
  children: [
    {
      id: "1:2", name: "Title", type: "TEXT",
      x: 16, y: 16, width: 288, height: 24,
      fills: [{ type: "SOLID", color: { r: 0, g: 0, b: 0, a: 1 } }],
      characters: "Hello World",
      style: { fontSize: 18, fontWeight: 700 },
      children: [],
    },
  ],
};

describe("traverseFigmaNode", () => {
  it("returns a RawNode with correct id and sourceType", () => {
    const raw = traverseFigmaNode(minimalFrame);
    assert.equal(raw.id, "1:1");
    assert.equal(raw.sourceType, "figma");
  });

  it("sets rawKind from Figma type", () => {
    const raw = traverseFigmaNode(minimalFrame);
    assert.equal(raw.rawKind, "FRAME");
  });

  it("sets rawName from Figma name", () => {
    const raw = traverseFigmaNode(minimalFrame);
    assert.equal(raw.rawName, "Card");
  });

  it("traverses children recursively", () => {
    const raw = traverseFigmaNode(minimalFrame);
    assert.equal(raw.children.length, 1);
    assert.equal(raw.children[0].id, "1:2");
    assert.equal(raw.children[0].rawKind, "TEXT");
  });

  it("sets textContent for TEXT nodes", () => {
    const raw = traverseFigmaNode(minimalFrame);
    assert.equal(raw.children[0].textContent, "Hello World");
  });

  it("adds signals for FRAME nodes", () => {
    const raw = traverseFigmaNode(minimalFrame);
    assert.ok(raw.signals.some(s => s.startsWith("type:")));
  });

  it("throws on non-object input", () => {
    assert.throws(() => traverseFigmaNode(null), /invalid figma node/i);
  });

  it("throws when id is missing", () => {
    assert.throws(() => traverseFigmaNode({ name: "X", type: "FRAME" }), /missing id/i);
  });
});
