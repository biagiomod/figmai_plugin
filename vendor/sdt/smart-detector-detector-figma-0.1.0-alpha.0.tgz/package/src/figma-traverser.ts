import type { RawNode } from "@smart-detector/schema";

interface FigmaStyle {
  fontSize?: number;
  fontWeight?: number;
  fontFamily?: string;
  fontStyle?: string;         // e.g. "Regular", "Italic", "Bold Italic"
  letterSpacingPx?: number;
  lineHeightPx?: number;
  textAlign?: string;
  textDecoration?: string;
  leadingTrim?: string;       // "CAP_HEIGHT" when Figma cap-height trim is enabled
}

interface FigmaFill {
  type: string;
  color?: { r: number; g: number; b: number; a: number };
}

interface FigmaNode {
  id: string;
  name?: string;
  type: string;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  fills?: FigmaFill[];
  characters?: string;
  characterCodes?: number[];   // Unicode code points for PUA/icon-font glyph round-trip
  style?: FigmaStyle;
  cornerRadius?: number;
  opacity?: number;
  visible?: boolean;
  strokes?: Array<{ type?: string }>;
  strokeWeight?: number;
  // Variable metadata (additive; consumed by token-audit)
  boundVariables?: Record<string, unknown>;
  resolvedVariableModes?: Record<string, string>;
  explicitVariableModes?: Record<string, string>;
  inferredVariables?: Record<string, unknown>;
  // Auto-layout (frame-level)
  layoutMode?: string;
  primaryAxisAlignItems?: string;
  counterAxisAlignItems?: string;
  paddingLeft?: number;
  paddingRight?: number;
  paddingTop?: number;
  paddingBottom?: number;
  itemSpacing?: number;
  children?: FigmaNode[];
}

function buildSignals(node: FigmaNode): string[] {
  const signals: string[] = [`type:${node.type}`];
  const lower = (node.name ?? "").toLowerCase();

  // ── Name hints ────────────────────────────────────────────────────────────
  if (lower) {
    signals.push(`name:${lower}`);
    if (/btn|button/.test(lower)) signals.push("name-hint:button");
    if (/heading|title|h[1-6](?:[^a-z]|$)/.test(lower)) signals.push("name-hint:heading");
    if (/\blabel\b/.test(lower)) signals.push("name-hint:label");
    if (/placeholder/.test(lower)) signals.push("name-hint:placeholder");
    if (/input|field|text.?field|form.?field/.test(lower)) signals.push("name-hint:input");
    if (/card/.test(lower)) signals.push("name-hint:card");
    if (/nav(bar|igation)?/.test(lower)) signals.push("name-hint:navigation");
    if (/modal|dialog/.test(lower)) signals.push("name-hint:modal");
    if (/icon/.test(lower)) signals.push("name-hint:icon");
    if (/image|img|photo|avatar/.test(lower)) signals.push("name-hint:image");
    if (/\blist\b/.test(lower)) signals.push("name-hint:list");
    if (/\btable\b/.test(lower)) signals.push("name-hint:table");
    if (/badge|tag|chip|pill/.test(lower)) signals.push("name-hint:badge");
    if (/toast|alert|notification|banner/.test(lower)) signals.push("name-hint:alert");
    if (/divider|separator/.test(lower)) signals.push("name-hint:divider");
    if (/checkbox|check.?box/.test(lower)) signals.push("name-hint:checkbox");
    if (/radio/.test(lower)) signals.push("name-hint:radio");
    if (/toggle|switch/.test(lower)) signals.push("name-hint:toggle");
    if (/select|dropdown/.test(lower)) signals.push("name-hint:select");
    if (/tooltip/.test(lower)) signals.push("name-hint:tooltip");
    if (/drawer|sidebar/.test(lower)) signals.push("name-hint:drawer");
  }

  // ── Text content & typography ─────────────────────────────────────────────
  if (node.type === "TEXT") {
    if (node.characters) {
      signals.push("has:text-content");
      signals.push(node.characters.length <= 40 ? "text:short" : "text:long");
    }
    const fw = node.style?.fontWeight ?? 400;
    const fs = node.style?.fontSize ?? 14;
    if (fw >= 700) signals.push("text:bold");
    else if (fw >= 600) signals.push("text:semibold");
    if (fs >= 24) signals.push("text:large");
    else if (fs >= 16) signals.push("text:medium");
    else if (fs <= 11) signals.push("text:tiny");
    else signals.push("text:small");
    if (node.style?.fontFamily) {
      signals.push(`font:family:${node.style.fontFamily.toLowerCase().replace(/\s+/g, "-")}`);
    }
    const styleName = (node.style?.fontStyle ?? "").toLowerCase();
    if (styleName.includes("italic")) signals.push("font:italic");
  }

  // ── Auto-layout ───────────────────────────────────────────────────────────
  if (node.layoutMode && node.layoutMode !== "NONE") {
    signals.push(`layout:${node.layoutMode === "VERTICAL" ? "vertical" : "horizontal"}`);
    const padH = (node.paddingLeft ?? 0) + (node.paddingRight ?? 0);
    const padV = (node.paddingTop ?? 0) + (node.paddingBottom ?? 0);
    if (padH > 0 || padV > 0) signals.push("has:padding");
    if ((node.itemSpacing ?? 0) > 0) signals.push("has:gap");
  }

  // ── Fills ─────────────────────────────────────────────────────────────────
  const fills = node.fills ?? [];
  const visibleFills = fills.filter(f => f.color && (f.color.a ?? 1) > 0.05);
  const hasSolid = visibleFills.some(f => f.type === "SOLID");
  const hasImage = fills.some(f => f.type === "IMAGE");
  if (hasSolid) signals.push("fill:solid");
  if (hasImage) signals.push("has:image-fill");
  if (!hasSolid && !hasImage) signals.push("fill:transparent");

  // ── Strokes ───────────────────────────────────────────────────────────────
  if (node.strokes && node.strokes.length > 0 && (node.strokeWeight ?? 0) > 0) {
    signals.push("has:stroke");
  }

  // ── Children ──────────────────────────────────────────────────────────────
  const childCount = node.children?.length ?? 0;
  if (childCount > 0) signals.push(`children:${childCount}`);
  if (childCount === 0 && node.type !== "TEXT") signals.push("leaf-node");

  // Check for direct text children
  if (node.children?.some(c => c.type === "TEXT" && c.characters)) {
    signals.push("has:text-child");
  }

  // ── Geometry ──────────────────────────────────────────────────────────────
  const w = node.width ?? 0;
  const h = node.height ?? 0;
  if (w > 0 && h > 0) {
    const ratio = w / h;
    if (ratio > 2.5) signals.push("shape:wide");
    else if (ratio < 0.4) signals.push("shape:tall");
    else if (ratio >= 0.8 && ratio <= 1.25) signals.push("shape:square");
  }

  if (node.cornerRadius && node.cornerRadius > 0) signals.push("has:corner-radius");
  if (node.opacity !== undefined && node.opacity < 1) signals.push("has:opacity");

  return signals;
}

function buildPath(parentPath: string, node: FigmaNode, index: number): string {
  const segment = node.name ? encodeURIComponent(node.name) : `[${index}]`;
  return parentPath === "/" ? `/${segment}` : `${parentPath}/${segment}`;
}

function traverseNode(node: FigmaNode, parentPath: string, index: number): RawNode {
  if (!node || typeof node !== "object") {
    throw new Error("Invalid Figma node: must be an object");
  }
  if (!node.id) {
    throw new Error("Invalid Figma node: missing id");
  }

  const path = buildPath(parentPath, node, index);
  const children = (node.children ?? []).map((child, i) => traverseNode(child, path, i));

  // Build metadata — preserve everything useful for rules and rendering
  const metadata: Record<string, unknown> = {
    figmaType: node.type,
    x: node.x ?? 0,
    y: node.y ?? 0,
    width: node.width ?? 0,
    height: node.height ?? 0,
  };
  if (node.fills?.length) metadata["fills"] = node.fills;
  if (node.characterCodes?.length) metadata["characterCodes"] = node.characterCodes;
  if (node.style) metadata["style"] = node.style;
  if (node.cornerRadius !== undefined) metadata["cornerRadius"] = node.cornerRadius;
  if (node.opacity !== undefined) metadata["opacity"] = node.opacity;
  if (node.strokeWeight !== undefined) metadata["strokeWeight"] = node.strokeWeight;
  if (node.strokes?.length) metadata["strokes"] = node.strokes;
  // Auto-layout
  if (node.layoutMode) metadata["layoutMode"] = node.layoutMode;
  if (node.primaryAxisAlignItems) metadata["primaryAxisAlignItems"] = node.primaryAxisAlignItems;
  if (node.counterAxisAlignItems) metadata["counterAxisAlignItems"] = node.counterAxisAlignItems;
  if (node.paddingLeft !== undefined) metadata["paddingLeft"] = node.paddingLeft;
  if (node.paddingRight !== undefined) metadata["paddingRight"] = node.paddingRight;
  if (node.paddingTop !== undefined) metadata["paddingTop"] = node.paddingTop;
  if (node.paddingBottom !== undefined) metadata["paddingBottom"] = node.paddingBottom;
  if (node.itemSpacing !== undefined) metadata["itemSpacing"] = node.itemSpacing;
  // ── Variable metadata (additive, consumed by token-audit) ────────────────
  if (node.boundVariables) metadata["boundVariables"] = node.boundVariables;
  if (node.resolvedVariableModes) metadata["resolvedVariableModes"] = node.resolvedVariableModes;
  if (node.explicitVariableModes) metadata["explicitVariableModes"] = node.explicitVariableModes;
  if (node.inferredVariables) metadata["inferredVariables"] = node.inferredVariables;

  return {
    id: node.id,
    sourceType: "figma",
    sourcePath: path,
    rawKind: node.type,
    rawName: node.name,
    textContent: node.type === "TEXT" ? node.characters : undefined,
    signals: buildSignals(node),
    attributes: {},
    metadata,
    children,
  };
}

export function traverseFigmaNode(input: unknown): RawNode {
  if (!input || typeof input !== "object") {
    throw new Error("Invalid Figma node: must be a non-null object");
  }
  return traverseNode(input as FigmaNode, "/", 0);
}
