import type { TaxonomyLookup } from "./lookup.js";

// Phase 0 stub — returns empty lookup maps.
//
// Phase 1 will:
//   1. Add "@design-system-toolkit/schema" to package.json dependencies.
//   2. Import TAXONOMY_REGISTRY from "@design-system-toolkit/schema".
//   3. Build the three maps from the registry entries.
export function buildTaxonomyLookup(): TaxonomyLookup {
  return {
    byName: new Map(),
    byCategory: new Map(),
    byRawKind: new Map(),
  };
}
