import type { TaxonomyCategory, TaxonomyEntryName, TaxonomyEntryRef } from "@smart-detector/taxonomy-contract";

export interface TaxonomyLookup {
  // Look up a taxonomy entry by its canonical name (e.g. "button", "hero")
  byName: Map<TaxonomyEntryName, TaxonomyEntryRef>;

  // Look up all entries in a category
  byCategory: Map<TaxonomyCategory, TaxonomyEntryRef[]>;

  // Look up a taxonomy entry by a raw artifact kind string
  // (e.g. Figma node type "FRAME", HTML tag "button")
  // Named byRawKind (not byKind) to avoid confusion with taxonomy kind families.
  byRawKind: Map<string, TaxonomyEntryRef>;
}
