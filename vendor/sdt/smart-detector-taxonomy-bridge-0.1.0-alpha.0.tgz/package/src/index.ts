export type { TaxonomyLookup } from "./lookup.js";
export { buildTaxonomyLookup } from "./bridge.js";
