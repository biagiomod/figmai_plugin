import type { DetectionNode, DetectionDraft } from "@smart-detector/schema";
import { assignCertainty } from "./confidence-rules.js";

function scoreNode(node: DetectionNode): DetectionNode {
  return {
    ...node,
    certainty: assignCertainty(node),
    children: node.children.map(scoreNode),
  };
}

// Traverses the DetectionDraft tree and assigns certainty to every node.
// Does not touch sourceKind, reviewState, or summary.
export function score(draft: DetectionDraft): DetectionDraft {
  return { ...draft, root: scoreNode(draft.root) };
}
