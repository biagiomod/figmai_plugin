import type { DetectionNode, CertaintyLevel } from "@smart-detector/schema";

// Assign certainty level based on sourceKind, signal quality, and ambiguity.
export function assignCertainty(node: DetectionNode): CertaintyLevel {
  if (node.candidateEntry === null) return "unknown";

  const { sourceKind, ambiguous, matchedSignals } = node;
  const sigCount = matchedSignals.length;

  // Explicit extraction from a native semantic source (Figma role, HTML element type)
  if (sourceKind === "extracted") {
    return ambiguous ? "inferred" : "exact";
  }

  // Inferred from signals — certainty depends on signal strength
  if (sourceKind === "inferred") {
    if (ambiguous) return "weak";
    if (sigCount >= 3) return "inferred";
    if (sigCount >= 1) return "weak";
    return "weak";
  }

  // blank / unknown sourceKind
  return "unknown";
}
