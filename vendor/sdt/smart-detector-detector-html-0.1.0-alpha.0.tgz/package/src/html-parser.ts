import type { RawNode } from "@smart-detector/schema";

// Phase 0 stub — returns a minimal root RawNode representing an HTML page.
// Phase 1 will parse the HTML string into a tree of RawNodes, collecting
// tag names, ARIA roles, class names, and text content as signals.
export function parseHtml(_html: string): RawNode {
  return {
    id: "stub-html-root",
    sourceType: "html",
    sourcePath: "/html",
    rawKind: "html",
    signals: [],
    attributes: {},
    metadata: {},
    children: [],
  };
}
