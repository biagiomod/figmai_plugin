import type { DetectionNode, DetectionDraft, DetectionTree } from "@smart-detector/schema";
import { determineReviewState } from "./review-rules.js";
import { summarize } from "./summarizer.js";

function reviewNode(node: DetectionNode): DetectionNode {
  return {
    ...node,
    reviewState: determineReviewState(node.certainty, node.ambiguous, node.candidateEntry),
    children: node.children.map(reviewNode),
  };
}

// Pass 1: assign reviewState to every node.
// Pass 2: compute and attach DetectionSummary.
// reviewer is the first and only stage that returns a complete DetectionTree.
export function review(draft: DetectionDraft): DetectionTree {
  const reviewedDraft: DetectionDraft = { ...draft, root: reviewNode(draft.root) };
  const summary = summarize(reviewedDraft);
  return { ...reviewedDraft, summary };
}
