import type { CertaintyLevel, ReviewState } from "@smart-detector/schema";

// Determine the ReviewState for a node based on its certainty, ambiguity,
// and whether a candidate was found.
//
// Rules:
//   candidateEntry = null OR certainty = "unknown" → "unresolved"
//   ambiguous = true OR certainty = "inferred" OR certainty = "weak" → "needs-review"
//   certainty = "exact" AND ambiguous = false → "accepted"
export function determineReviewState(
  certainty: CertaintyLevel,
  ambiguous: boolean,
  candidateEntry: string | null
): ReviewState {
  if (candidateEntry === null || certainty === "unknown") return "unresolved";
  if (ambiguous || certainty === "weak" || certainty === "inferred") return "needs-review";
  return "accepted";
}
