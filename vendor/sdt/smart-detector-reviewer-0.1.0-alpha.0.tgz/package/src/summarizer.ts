import type { DetectionNode, DetectionDraft, DetectionSummary } from "@smart-detector/schema";

function countNodes(node: DetectionNode, acc: DetectionSummary): void {
  acc.total += 1;

  if (node.certainty === "exact") acc.exact += 1;
  else if (node.certainty === "inferred") acc.inferred += 1;
  else if (node.certainty === "weak") acc.weak += 1;
  else acc.unknown += 1;

  if (node.ambiguous) acc.ambiguous += 1;

  if (node.reviewState === "accepted") acc.accepted += 1;
  else if (node.reviewState === "needs-review") acc.needsReview += 1;
  else acc.unresolved += 1;

  for (const child of node.children) {
    countNodes(child, acc);
  }
}

export function summarize(draft: DetectionDraft): DetectionSummary {
  const acc: DetectionSummary = {
    total: 0, exact: 0, inferred: 0, weak: 0, unknown: 0,
    ambiguous: 0, accepted: 0, needsReview: 0, unresolved: 0,
  };
  countNodes(draft.root, acc);
  return acc;
}
