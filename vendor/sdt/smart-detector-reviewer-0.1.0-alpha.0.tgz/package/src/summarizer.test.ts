import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { summarize } from "./summarizer.ts";
import type { DetectionDraft } from "@smart-detector/schema";

const makeNode = (overrides: object = {}) => ({
  id: "n1", sourceType: "figma" as const, sourcePath: "/",
  candidateEntry: null, candidateCategory: null, candidateKindFamily: null,
  sourceKind: "blank" as const, certainty: "unknown" as const, reviewState: "unresolved" as const,
  rationale: "stub", matchedSignals: [], unmatchedSignals: [],
  ambiguous: false, alternativeCandidates: [], children: [],
  ...overrides,
});

describe("summarize", () => {
  it("counts total nodes recursively", () => {
    const child = makeNode({ id: "n2" });
    const draft: DetectionDraft = {
      version: "1", sourceType: "figma", sourceRef: "r", detectedAt: "",
      root: { ...makeNode({ id: "n1" }), children: [child] } as any,
    };
    const summary = summarize(draft);
    assert.equal(summary.total, 2);
  });

  it("counts accepted nodes", () => {
    const accepted = makeNode({ id: "n2", reviewState: "accepted" as const });
    const draft: DetectionDraft = {
      version: "1", sourceType: "figma", sourceRef: "r", detectedAt: "",
      root: { ...makeNode({ id: "n1" }), children: [accepted] } as any,
    };
    const summary = summarize(draft);
    assert.equal(summary.accepted, 1);
    assert.equal(summary.unresolved, 1); // root is unresolved
  });

  it("counts certainty levels", () => {
    const exact = makeNode({ id: "n2", certainty: "exact" as const, sourceKind: "explicit" as const });
    const weak = makeNode({ id: "n3", certainty: "weak" as const, sourceKind: "explicit" as const });
    const draft: DetectionDraft = {
      version: "1", sourceType: "figma", sourceRef: "r", detectedAt: "",
      root: { ...makeNode({ id: "n1" }), children: [exact, weak] } as any,
    };
    const summary = summarize(draft);
    assert.equal(summary.exact, 1);
    assert.equal(summary.weak, 1);
    assert.equal(summary.unknown, 1);
  });
});
