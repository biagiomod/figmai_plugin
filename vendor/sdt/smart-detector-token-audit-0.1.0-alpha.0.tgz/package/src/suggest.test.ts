import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { rankColorSuggestions } from "./suggest.ts";
import { normalizeCatalog } from "./variable-catalog.ts";
import type { VariableCatalogSnapshot } from "@smart-detector/schema";

const snapshot: VariableCatalogSnapshot = {
  collections: [
    { id: "c1", name: "Colors", modes: [{ modeId: "m1", name: "Default" }], defaultModeId: "m1" },
  ],
  variables: [
    {
      id: "v-blue",
      name: "color/brand/primary",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: { m1: { type: "COLOR", r: 0.2, g: 0.5, b: 1, a: 1 } },
    },
    {
      id: "v-muted",
      name: "color/text/muted",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["TEXT_FILL"],
      valuesByMode: { m1: { type: "COLOR", r: 0.5, g: 0.5, b: 0.5, a: 1 } },
    },
    {
      id: "v-black",
      name: "color/neutral/black",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: { m1: { type: "COLOR", r: 0, g: 0, b: 0, a: 1 } },
    },
    {
      id: "v-size",
      name: "size/md",
      collectionId: "c1",
      resolvedType: "FLOAT",
      scopes: ["WIDTH_HEIGHT"],
      valuesByMode: { m1: { type: "FLOAT", value: 16 } },
    },
    {
      id: "v-gone",
      name: "color/deprecated",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: { m1: { type: "COLOR", r: 0.2, g: 0.5, b: 1, a: 1 } },
      deleted: true,
    },
  ],
};

const cat = normalizeCatalog(snapshot);

describe("rankColorSuggestions", () => {
  it("filters out non-COLOR variables and deleted variables", () => {
    const out = rankColorSuggestions(cat, {
      color: { r: 0.2, g: 0.5, b: 1, a: 1 },
      scope: "ALL_FILLS",
    });
    const ids = out.map(s => s.variableId);
    assert.ok(!ids.includes("v-size"));
    assert.ok(!ids.includes("v-gone"));
  });

  it("respects scope filter (TEXT_FILL): exact text-scoped match wins", () => {
    const out = rankColorSuggestions(cat, {
      color: { r: 0.5, g: 0.5, b: 0.5, a: 1 },
      scope: "TEXT_FILL",
    });
    // ALL_FILLS is a superset of *_FILL scopes, so v-blue/v-black also pass
    // the filter. Only the exact-color, text-scoped v-muted should rank first.
    assert.equal(out[0]!.variableId, "v-muted");
    assert.equal(out[0]!.confidence, "high");
    const ids = out.map(s => s.variableId);
    assert.ok(!ids.includes("v-size"), "non-COLOR filtered");
    assert.ok(!ids.includes("v-gone"), "deleted filtered");
  });

  it("returns exact match first with high confidence", () => {
    const out = rankColorSuggestions(cat, {
      color: { r: 0.2, g: 0.5, b: 1, a: 1 },
      scope: "ALL_FILLS",
    });
    assert.equal(out[0]!.variableId, "v-blue");
    assert.equal(out[0]!.confidence, "high");
  });

  it("returns at most 3 suggestions", () => {
    const out = rankColorSuggestions(cat, {
      color: { r: 0.2, g: 0.5, b: 1, a: 1 },
      scope: "ALL_FILLS",
    });
    assert.ok(out.length <= 3);
  });

  it("is deterministic across invocations", () => {
    const a = rankColorSuggestions(cat, {
      color: { r: 0.4, g: 0.4, b: 0.4, a: 1 },
      scope: "ALL_FILLS",
    });
    const b = rankColorSuggestions(cat, {
      color: { r: 0.4, g: 0.4, b: 0.4, a: 1 },
      scope: "ALL_FILLS",
    });
    assert.deepEqual(a.map(s => s.variableId), b.map(s => s.variableId));
  });

  it("records name-hint boost as a scoring reason (secondary weight)", () => {
    // Name-hints are a secondary weight; they should not override raw color
    // distance, but they must be reflected in the candidate's reasons array.
    const withHint = rankColorSuggestions(cat, {
      color: { r: 0.2, g: 0.5, b: 1, a: 1 },     // exact v-blue color
      scope: "ALL_FILLS",
      nameHint: "primary",
    });
    const blueWithHint = withHint.find(s => s.variableId === "v-blue")!;
    assert.ok(
      blueWithHint.reasons.some(r => r.includes("name-hint")),
      "name-hint:<hint> reason should appear when the variable name matches",
    );

    const withoutHint = rankColorSuggestions(cat, {
      color: { r: 0.2, g: 0.5, b: 1, a: 1 },
      scope: "ALL_FILLS",
    });
    const blueWithoutHint = withoutHint.find(s => s.variableId === "v-blue")!;
    assert.ok(
      blueWithHint.score >= blueWithoutHint.score,
      "name-hint match must not lower a candidate's score",
    );
  });

  it("returns empty when no candidates match", () => {
    const emptySnapshot: VariableCatalogSnapshot = { collections: [], variables: [] };
    const out = rankColorSuggestions(normalizeCatalog(emptySnapshot), {
      color: { r: 0.5, g: 0.5, b: 0.5, a: 1 },
      scope: "ALL_FILLS",
    });
    assert.deepEqual(out, []);
  });
});
