import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { evaluateModeCoverage } from "./modes.ts";
import { normalizeCatalog } from "./variable-catalog.ts";
import type { VariableCatalogSnapshot } from "@smart-detector/schema";

const snapshot: VariableCatalogSnapshot = {
  collections: [
    {
      id: "c1",
      name: "Colors",
      modes: [
        { modeId: "light", name: "Light" },
        { modeId: "dark", name: "Dark" },
      ],
      defaultModeId: "light",
    },
  ],
  variables: [
    {
      id: "complete",
      name: "color/complete",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: {
        light: { type: "COLOR", r: 1, g: 1, b: 1, a: 1 },
        dark:  { type: "COLOR", r: 0, g: 0, b: 0, a: 1 },
      },
    },
    {
      id: "missing-dark",
      name: "color/missing-dark",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: {
        light: { type: "COLOR", r: 1, g: 1, b: 1, a: 1 },
      },
    },
    {
      id: "alias-ok",
      name: "color/alias-ok",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: {
        light: { type: "ALIAS", variableId: "complete" },
        dark:  { type: "ALIAS", variableId: "complete" },
      },
    },
    {
      id: "alias-broken",
      name: "color/alias-broken",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: {
        light: { type: "ALIAS", variableId: "does-not-exist" },
        dark:  { type: "ALIAS", variableId: "does-not-exist" },
      },
    },
  ],
};

const cat = normalizeCatalog(snapshot);

describe("evaluateModeCoverage", () => {
  it("ready=true when all modes have concrete values", () => {
    const cov = evaluateModeCoverage(cat, "complete");
    assert.equal(cov.ready, true);
    assert.deepEqual(cov.missingModeIds, []);
    assert.deepEqual(cov.requiredModeIds.sort(), ["dark", "light"]);
    assert.equal(cov.collectionId, "c1");
  });

  it("ready=false when a mode is missing a value", () => {
    const cov = evaluateModeCoverage(cat, "missing-dark");
    assert.equal(cov.ready, false);
    assert.deepEqual(cov.missingModeIds, ["dark"]);
  });

  it("ready=true when alias resolves through one hop", () => {
    const cov = evaluateModeCoverage(cat, "alias-ok");
    assert.equal(cov.ready, true);
  });

  it("ready=false when alias target is missing", () => {
    const cov = evaluateModeCoverage(cat, "alias-broken");
    assert.equal(cov.ready, false);
    assert.deepEqual(cov.missingModeIds.sort(), ["dark", "light"]);
  });

  it("returns ready=false with empty requiredModeIds for unknown variable", () => {
    const cov = evaluateModeCoverage(cat, "missing");
    assert.equal(cov.ready, false);
    assert.equal(cov.collectionId, "");
    assert.deepEqual(cov.requiredModeIds, []);
  });
});
