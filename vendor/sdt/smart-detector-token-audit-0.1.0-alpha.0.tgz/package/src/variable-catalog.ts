import type {
  VariableCatalogSnapshot,
  VariableCollectionInfo,
  VariableInfo,
  VariableResolvedType,
} from "@smart-detector/schema";

export interface NormalizedCatalog {
  variableById: Map<string, VariableInfo>;
  collectionById: Map<string, VariableCollectionInfo>;
}

export function normalizeCatalog(snapshot: VariableCatalogSnapshot): NormalizedCatalog {
  const variableById = new Map<string, VariableInfo>();
  for (const v of snapshot.variables) variableById.set(v.id, v);
  const collectionById = new Map<string, VariableCollectionInfo>();
  for (const c of snapshot.collections) collectionById.set(c.id, c);
  return { variableById, collectionById };
}

export function lookupVariable(
  catalog: NormalizedCatalog,
  variableId: string,
): VariableInfo | null {
  return catalog.variableById.get(variableId) ?? null;
}

export function listByType(
  catalog: NormalizedCatalog,
  type: VariableResolvedType,
): VariableInfo[] {
  const out: VariableInfo[] = [];
  for (const v of catalog.variableById.values()) {
    if (v.resolvedType === type) out.push(v);
  }
  out.sort((a, b) => a.name.localeCompare(b.name));
  return out;
}
