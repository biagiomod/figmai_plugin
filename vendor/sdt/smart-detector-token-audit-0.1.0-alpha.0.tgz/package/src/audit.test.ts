import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { auditTokens } from "./audit.ts";
import type { VariableCatalogSnapshot } from "@smart-detector/schema";

const catalog: VariableCatalogSnapshot = {
  collections: [
    {
      id: "c1",
      name: "Colors",
      modes: [
        { modeId: "m-light", name: "Light" },
        { modeId: "m-dark", name: "Dark" },
      ],
      defaultModeId: "m-light",
    },
  ],
  variables: [
    {
      id: "v-primary",
      name: "color/brand/primary",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: {
        "m-light": { type: "COLOR", r: 0.2, g: 0.5, b: 1, a: 1 },
        "m-dark":  { type: "COLOR", r: 0.3, g: 0.6, b: 1, a: 1 },
      },
    },
    {
      id: "v-missing-dark",
      name: "color/accent",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: {
        "m-light": { type: "COLOR", r: 0.9, g: 0.2, b: 0.2, a: 1 },
      },
    },
  ],
};

describe("auditTokens", () => {
  it("emits unbound-color for a SOLID fill without a binding", () => {
    const node = {
      id: "n1",
      name: "Card",
      type: "FRAME",
      fills: [{ type: "SOLID", color: { r: 0.2, g: 0.5, b: 1, a: 1 } }],
      children: [],
    };
    const report = auditTokens(node, catalog);
    assert.equal(report.findings.length, 1);
    const f = report.findings[0]!;
    assert.equal(f.kind, "unbound-color");
    assert.equal(f.field, "fills[0]");
    assert.equal(f.nodeId, "n1");
    assert.equal(f.suggestions[0]!.variableId, "v-primary");
  });

  it("skips invisible fills", () => {
    const node = {
      id: "n2",
      type: "FRAME",
      fills: [{ type: "SOLID", visible: false, color: { r: 1, g: 0, b: 0, a: 1 } }],
      children: [],
    };
    const report = auditTokens(node, catalog);
    assert.equal(report.findings.length, 0);
  });

  it("skips fully transparent fills", () => {
    const node = {
      id: "n3",
      type: "FRAME",
      fills: [{ type: "SOLID", color: { r: 1, g: 0, b: 0, a: 0 } }],
      children: [],
    };
    const report = auditTokens(node, catalog);
    assert.equal(report.findings.length, 0);
  });

  it("does NOT emit unbound-color when fill is bound to a known variable", () => {
    const node = {
      id: "n4",
      type: "FRAME",
      fills: [{ type: "SOLID", color: { r: 0.2, g: 0.5, b: 1, a: 1 } }],
      boundVariables: { fills: [{ type: "VARIABLE_ALIAS", id: "v-primary" }] },
      children: [],
    };
    const report = auditTokens(node, catalog);
    assert.equal(
      report.findings.filter(f => f.kind === "unbound-color").length,
      0,
    );
  });

  it("emits orphaned-binding when fill binds an id not in the catalog", () => {
    const node = {
      id: "n5",
      type: "FRAME",
      fills: [{ type: "SOLID", color: { r: 0.2, g: 0.5, b: 1, a: 1 } }],
      boundVariables: { fills: [{ type: "VARIABLE_ALIAS", id: "v-does-not-exist" }] },
      children: [],
    };
    const report = auditTokens(node, catalog);
    const orphans = report.findings.filter(f => f.kind === "orphaned-binding");
    assert.equal(orphans.length, 1);
    assert.equal(orphans[0]!.field, "boundVariables.fills[0]");
    assert.equal(orphans[0]!.severity, "error");
    assert.ok(orphans[0]!.reasons.includes("variable-not-in-catalog"));
  });

  it("emits mode-incomplete when bound variable has missing modes", () => {
    const node = {
      id: "n6",
      type: "FRAME",
      fills: [{ type: "SOLID", color: { r: 0.9, g: 0.2, b: 0.2, a: 1 } }],
      boundVariables: { fills: [{ type: "VARIABLE_ALIAS", id: "v-missing-dark" }] },
      children: [],
    };
    const report = auditTokens(node, catalog);
    const modeFindings = report.findings.filter(f => f.kind === "mode-incomplete");
    assert.equal(modeFindings.length, 1);
    assert.equal(modeFindings[0]!.severity, "info");
    assert.deepEqual(modeFindings[0]!.modeCoverage?.missingModeIds, ["m-dark"]);
  });

  it("walks children depth-first", () => {
    const node = {
      id: "root",
      type: "FRAME",
      fills: [{ type: "SOLID", color: { r: 0.2, g: 0.5, b: 1, a: 1 } }],
      children: [
        {
          id: "child",
          type: "TEXT",
          characters: "Hi",
          fills: [{ type: "SOLID", color: { r: 0, g: 0, b: 0, a: 1 } }],
          children: [],
        },
      ],
    };
    const report = auditTokens(node, catalog);
    const nodeIds = report.findings.map(f => f.nodeId);
    assert.ok(nodeIds.includes("root"));
    assert.ok(nodeIds.includes("child"));
  });

  it("summary counts findings by kind and severity", () => {
    const node = {
      id: "s1",
      type: "FRAME",
      fills: [
        { type: "SOLID", color: { r: 0.2, g: 0.5, b: 1, a: 1 } },
        { type: "SOLID", color: { r: 0.9, g: 0.2, b: 0.2, a: 1 } },
      ],
      children: [],
    };
    const report = auditTokens(node, catalog);
    assert.equal(report.summary.total, report.findings.length);
    assert.equal(report.summary.byKind["unbound-color"], 2);
    assert.equal(report.summary.bySeverity["warn"], 2);
    assert.equal(report.summary.byKind["orphaned-binding"], 0);
  });

  it("sourceRef defaults to root node id and auditedAt is an ISO string", () => {
    const node = { id: "root-x", type: "FRAME", children: [] };
    const report = auditTokens(node, catalog);
    assert.equal(report.sourceRef, "root-x");
    assert.equal(report.version, "1");
    assert.ok(!Number.isNaN(Date.parse(report.auditedAt)));
  });

  it("options.sourceRef overrides the default", () => {
    const node = { id: "root-x", type: "FRAME", children: [] };
    const report = auditTokens(node, catalog, { sourceRef: "custom" });
    assert.equal(report.sourceRef, "custom");
  });

  it("throws on null input", () => {
    assert.throws(
      () => auditTokens(null as unknown as { id: string; type: string }, catalog),
      /Invalid Figma node/i,
    );
  });

  it("autoFix set only when suggestion is high-confidence and mode-ready", () => {
    const node = {
      id: "n7",
      type: "FRAME",
      fills: [{ type: "SOLID", color: { r: 0.2, g: 0.5, b: 1, a: 1 } }],
      children: [],
    };
    const report = auditTokens(node, catalog);
    const f = report.findings.find(x => x.kind === "unbound-color")!;
    assert.ok(f.autoFix);
    assert.equal(f.autoFix?.kind, "bind-paint-variable");
    assert.equal(f.autoFix?.variableId, "v-primary");
    assert.equal(f.autoFix?.safe, true);
    assert.equal(f.autoFix?.requiresConfirmation, true);
  });
});
