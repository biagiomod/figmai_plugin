import type { SuggestedVariable, VariableInfo, VariableValue } from "@smart-detector/schema";
import type { NormalizedCatalog } from "./variable-catalog.ts";
import { evaluateModeCoverage } from "./modes.ts";

export interface ColorTarget {
  r: number; g: number; b: number; a: number;
}

export interface RankColorOptions {
  color: ColorTarget;
  scope: string;             // e.g. "ALL_FILLS", "TEXT_FILL", "FRAME_FILL"
  nameHint?: string;
  maxResults?: number;       // defaults to 3
}

function colorDistance(a: ColorTarget, b: ColorTarget): number {
  const dr = a.r - b.r, dg = a.g - b.g, db = a.b - b.b, da = a.a - b.a;
  return Math.sqrt((dr * dr + dg * dg + db * db + da * da) / 4);
}

function exactColorMatch(a: ColorTarget, b: ColorTarget): boolean {
  return Math.abs(a.r - b.r) < 1e-3
    && Math.abs(a.g - b.g) < 1e-3
    && Math.abs(a.b - b.b) < 1e-3
    && Math.abs(a.a - b.a) < 1e-3;
}

function scopePasses(variableScopes: string[], targetScope: string): boolean {
  if (variableScopes.includes("ALL_SCOPES")) return true;
  if (variableScopes.includes(targetScope)) return true;
  // ALL_FILLS covers FRAME_FILL / SHAPE_FILL / TEXT_FILL by convention.
  if (variableScopes.includes("ALL_FILLS") && targetScope.endsWith("_FILL")) return true;
  return false;
}

function confidenceFor(score: number): SuggestedVariable["confidence"] {
  if (score >= 90) return "high";
  if (score >= 70) return "medium";
  return "low";
}

function firstConcreteColor(
  catalog: NormalizedCatalog,
  variable: VariableInfo,
): ColorTarget | null {
  const collection = catalog.collectionById.get(variable.collectionId);
  const modeId = collection?.defaultModeId;
  if (!modeId) return null;
  const v = variable.valuesByMode[modeId];
  return resolveColor(catalog, v, 0);
}

function resolveColor(
  catalog: NormalizedCatalog,
  value: VariableValue | undefined,
  hops: number,
): ColorTarget | null {
  if (!value) return null;
  if (value.type === "COLOR") return { r: value.r, g: value.g, b: value.b, a: value.a };
  if (value.type !== "ALIAS" || hops >= 4) return null;
  const target = catalog.variableById.get(value.variableId);
  if (!target) return null;
  const modeId = catalog.collectionById.get(target.collectionId)?.defaultModeId;
  if (!modeId) return null;
  return resolveColor(catalog, target.valuesByMode[modeId], hops + 1);
}

export function rankColorSuggestions(
  catalog: NormalizedCatalog,
  options: RankColorOptions,
): SuggestedVariable[] {
  const max = options.maxResults ?? 3;
  const hint = options.nameHint?.toLowerCase().trim() ?? "";

  interface Candidate {
    variable: VariableInfo;
    score: number;
    reasons: string[];
  }
  const candidates: Candidate[] = [];

  for (const variable of catalog.variableById.values()) {
    if (variable.resolvedType !== "COLOR") continue;
    if (variable.deleted) continue;
    if (!scopePasses(variable.scopes, options.scope)) continue;
    const reasons: string[] = [];
    const color = firstConcreteColor(catalog, variable);
    const distance = color ? colorDistance(options.color, color) : 1;
    let score = Math.max(0, Math.min(100, Math.round(100 - distance * 100)));
    reasons.push(`color-distance=${distance.toFixed(3)}`);
    if (color && exactColorMatch(options.color, color)) {
      score += 20;
      reasons.push("exact-default-mode-match");
    }
    if (hint && variable.name.toLowerCase().includes(hint)) {
      score += 10;
      reasons.push(`name-hint:${hint}`);
    }
    if (!variable.remote) {
      score += 5;
      reasons.push("local-collection");
    }
    candidates.push({ variable, score, reasons });
  }

  candidates.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    const byName = a.variable.name.localeCompare(b.variable.name);
    if (byName !== 0) return byName;
    return a.variable.id.localeCompare(b.variable.id);
  });

  return candidates.slice(0, max).map(c => ({
    variableId: c.variable.id,
    collectionId: c.variable.collectionId,
    variableName: c.variable.name,
    score: c.score,
    confidence: confidenceFor(c.score),
    reasons: c.reasons,
    modeCoverage: evaluateModeCoverage(catalog, c.variable.id),
  }));
}
