import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { normalizeCatalog, lookupVariable, listByType } from "./variable-catalog.ts";
import type { VariableCatalogSnapshot } from "@smart-detector/schema";

const snapshot: VariableCatalogSnapshot = {
  collections: [
    {
      id: "c1",
      name: "Colors",
      modes: [
        { modeId: "m-light", name: "Light" },
        { modeId: "m-dark", name: "Dark" },
      ],
      defaultModeId: "m-light",
    },
  ],
  variables: [
    {
      id: "v-primary",
      name: "color/brand/primary",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: {
        "m-light": { type: "COLOR", r: 0.2, g: 0.5, b: 1, a: 1 },
        "m-dark":  { type: "COLOR", r: 0.3, g: 0.6, b: 1, a: 1 },
      },
    },
    {
      id: "v-muted",
      name: "color/text/muted",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["TEXT_FILL"],
      valuesByMode: {
        "m-light": { type: "COLOR", r: 0.5, g: 0.5, b: 0.5, a: 1 },
      },
    },
    {
      id: "v-gone",
      name: "color/deprecated",
      collectionId: "c1",
      resolvedType: "COLOR",
      scopes: ["ALL_FILLS"],
      valuesByMode: {},
      deleted: true,
    },
  ],
};

describe("normalizeCatalog", () => {
  it("builds a variableById map", () => {
    const cat = normalizeCatalog(snapshot);
    assert.equal(cat.variableById.get("v-primary")?.name, "color/brand/primary");
    assert.equal(cat.variableById.get("missing"), undefined);
  });

  it("builds a collectionById map", () => {
    const cat = normalizeCatalog(snapshot);
    assert.equal(cat.collectionById.get("c1")?.modes.length, 2);
  });

  it("flags deleted variables", () => {
    const cat = normalizeCatalog(snapshot);
    assert.equal(cat.variableById.get("v-gone")?.deleted, true);
  });

  it("exposes lookupVariable that returns null for unknown ids", () => {
    const cat = normalizeCatalog(snapshot);
    assert.equal(lookupVariable(cat, "does-not-exist"), null);
    assert.equal(lookupVariable(cat, "v-primary")?.id, "v-primary");
  });

  it("listByType returns variables filtered by resolvedType, sorted by name", () => {
    const cat = normalizeCatalog(snapshot);
    const colors = listByType(cat, "COLOR");
    const names = colors.map(v => v.name);
    assert.deepEqual(names, [
      "color/brand/primary",
      "color/deprecated",
      "color/text/muted",
    ]);
  });

  it("is stable: same input produces same output", () => {
    const a = normalizeCatalog(snapshot);
    const b = normalizeCatalog(snapshot);
    assert.deepEqual(
      listByType(a, "COLOR").map(v => v.id),
      listByType(b, "COLOR").map(v => v.id),
    );
  });
});
