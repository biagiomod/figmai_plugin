export { auditTokens } from "./audit.ts";
export type { AuditOptions } from "./audit.ts";
export { normalizeCatalog, lookupVariable, listByType } from "./variable-catalog.ts";
export type { NormalizedCatalog } from "./variable-catalog.ts";
export { rankColorSuggestions } from "./suggest.ts";
export type { RankColorOptions, ColorTarget } from "./suggest.ts";
export { evaluateModeCoverage } from "./modes.ts";

// Re-export DTOs from schema so consumers can import from one place.
export type {
  VariableResolvedType,
  VariableCatalogSnapshot,
  VariableCollectionInfo,
  VariableInfo,
  VariableValue,
  FindingKind,
  FindingSeverity,
  TokenAuditFinding,
  SuggestedVariable,
  ModeCoverage,
  FixIntentKind,
  FixIntent,
  TokenAuditReport,
  TokenAuditSummary,
} from "@smart-detector/schema";
