import type {
  TokenAuditReport,
  TokenAuditFinding,
  TokenAuditSummary,
  FindingKind,
  FindingSeverity,
  SuggestedVariable,
  FixIntent,
  VariableCatalogSnapshot,
} from "@smart-detector/schema";
import { normalizeCatalog, type NormalizedCatalog } from "./variable-catalog.ts";
import { rankColorSuggestions } from "./suggest.ts";
import { evaluateModeCoverage } from "./modes.ts";

export interface AuditOptions {
  sourceRef?: string;
}

interface FigmaLikeNode {
  id: string;
  name?: string;
  type: string;
  fills?: Array<{
    type?: string;
    visible?: boolean;
    color?: { r: number; g: number; b: number; a?: number };
  }>;
  boundVariables?: {
    fills?: Array<{ id?: string }>;
  };
  children?: FigmaLikeNode[];
}

function assertNode(input: unknown): FigmaLikeNode {
  if (!input || typeof input !== "object") {
    throw new Error("Invalid Figma node: must be a non-null object");
  }
  const n = input as FigmaLikeNode;
  if (typeof n.id !== "string" || n.id.length === 0) {
    throw new Error("Invalid Figma node: missing id");
  }
  if (typeof n.type !== "string") {
    throw new Error("Invalid Figma node: missing type");
  }
  return n;
}

function scopeForNode(node: FigmaLikeNode): string {
  return node.type === "TEXT" ? "TEXT_FILL" : "ALL_FILLS";
}

function makeFindingId(nodeId: string, field: string, kind: FindingKind): string {
  return `${nodeId}:${field}:${kind}`;
}

function buildAutoFix(
  nodeId: string,
  field: string,
  suggestions: SuggestedVariable[],
): FixIntent | undefined {
  const top = suggestions[0];
  if (!top) return undefined;
  if (top.confidence !== "high") return undefined;
  if (!top.modeCoverage.ready) return undefined;
  return {
    kind: "bind-paint-variable",
    nodeId,
    field,
    variableId: top.variableId,
    collectionId: top.collectionId,
    safe: true,
    requiresConfirmation: true,
  };
}

function auditFills(
  node: FigmaLikeNode,
  catalog: NormalizedCatalog,
  findings: TokenAuditFinding[],
): void {
  const fills = node.fills ?? [];
  const bindings = node.boundVariables?.fills ?? [];
  for (let i = 0; i < fills.length; i++) {
    const fill = fills[i];
    if (!fill || fill.type !== "SOLID") continue;
    if (fill.visible === false) continue;
    const color = fill.color;
    if (!color) continue;
    const alpha = color.a ?? 1;
    if (alpha <= 0.05) continue;

    const binding = bindings[i];
    const boundId = binding?.id;
    const field = `fills[${i}]`;
    const bindingField = `boundVariables.fills[${i}]`;
    const suggestions = rankColorSuggestions(catalog, {
      color: { r: color.r, g: color.g, b: color.b, a: alpha },
      scope: scopeForNode(node),
      ...(node.name ? { nameHint: node.name } : {}),
    });

    if (!boundId) {
      const autoFix = buildAutoFix(node.id, field, suggestions);
      findings.push({
        id: makeFindingId(node.id, field, "unbound-color"),
        kind: "unbound-color",
        severity: "warn",
        nodeId: node.id,
        ...(node.name ? { nodeName: node.name } : {}),
        field,
        message: `Raw color fill on ${node.type} is not bound to a variable.`,
        reasons: ["no-binding"],
        suggestions,
        ...(autoFix ? { autoFix } : {}),
      });
      continue;
    }

    const variable = catalog.variableById.get(boundId);
    if (!variable) {
      findings.push({
        id: makeFindingId(node.id, bindingField, "orphaned-binding"),
        kind: "orphaned-binding",
        severity: "error",
        nodeId: node.id,
        ...(node.name ? { nodeName: node.name } : {}),
        field: bindingField,
        message: `Fill binds variable ${boundId}, which is not present in the catalog.`,
        reasons: ["variable-not-in-catalog"],
        suggestions,
      });
      continue;
    }
    if (variable.deleted) {
      findings.push({
        id: makeFindingId(node.id, bindingField, "orphaned-binding"),
        kind: "orphaned-binding",
        severity: "error",
        nodeId: node.id,
        ...(node.name ? { nodeName: node.name } : {}),
        field: bindingField,
        message: `Fill binds variable "${variable.name}" which is marked deleted.`,
        reasons: ["variable-deleted"],
        suggestions,
      });
      continue;
    }
    const coverage = evaluateModeCoverage(catalog, boundId);
    if (!coverage.ready) {
      findings.push({
        id: makeFindingId(node.id, bindingField, "mode-incomplete"),
        kind: "mode-incomplete",
        severity: "info",
        nodeId: node.id,
        ...(node.name ? { nodeName: node.name } : {}),
        field: bindingField,
        message: `Bound variable "${variable.name}" is missing values for mode(s): ${coverage.missingModeIds.join(", ")}.`,
        reasons: ["mode-values-missing"],
        suggestions: [],
        modeCoverage: coverage,
      });
    }
  }
}

function walk(
  node: FigmaLikeNode,
  catalog: NormalizedCatalog,
  findings: TokenAuditFinding[],
): void {
  auditFills(node, catalog, findings);
  for (const child of node.children ?? []) {
    const safeChild = assertNode(child);
    walk(safeChild, catalog, findings);
  }
}

function summarize(findings: TokenAuditFinding[]): TokenAuditSummary {
  const byKind: Record<FindingKind, number> = {
    "unbound-color": 0,
    "unbound-typography": 0,
    "orphaned-binding": 0,
    "mode-incomplete": 0,
    "mode-mismatch": 0,
  };
  const bySeverity: Record<FindingSeverity, number> = {
    info: 0,
    warn: 0,
    error: 0,
  };
  for (const f of findings) {
    byKind[f.kind]++;
    bySeverity[f.severity]++;
  }
  return { total: findings.length, byKind, bySeverity };
}

export function auditTokens(
  figmaNode: unknown,
  catalogSnapshot: VariableCatalogSnapshot,
  options: AuditOptions = {},
): TokenAuditReport {
  const root = assertNode(figmaNode);
  const catalog = normalizeCatalog(catalogSnapshot);
  const findings: TokenAuditFinding[] = [];
  walk(root, catalog, findings);
  return {
    version: "1",
    sourceRef: options.sourceRef ?? root.id,
    auditedAt: new Date().toISOString(),
    findings,
    summary: summarize(findings),
  };
}
