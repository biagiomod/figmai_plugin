import type { ModeCoverage, VariableValue } from "@smart-detector/schema";
import type { NormalizedCatalog } from "./variable-catalog.js";

const ALIAS_HOP_LIMIT = 4;

function resolveToConcrete(
  catalog: NormalizedCatalog,
  value: VariableValue | undefined,
  hops: number,
): VariableValue | null {
  if (!value) return null;
  if (value.type !== "ALIAS") return value;
  if (hops >= ALIAS_HOP_LIMIT) return null;
  const target = catalog.variableById.get(value.variableId);
  if (!target) return null;
  const defaultMode = catalog.collectionById.get(target.collectionId)?.defaultModeId;
  if (!defaultMode) return null;
  return resolveToConcrete(catalog, target.valuesByMode[defaultMode], hops + 1);
}

export function evaluateModeCoverage(
  catalog: NormalizedCatalog,
  variableId: string,
): ModeCoverage {
  const variable = catalog.variableById.get(variableId);
  if (!variable) {
    return { ready: false, collectionId: "", requiredModeIds: [], missingModeIds: [] };
  }
  const collection = catalog.collectionById.get(variable.collectionId);
  if (!collection) {
    return { ready: false, collectionId: variable.collectionId, requiredModeIds: [], missingModeIds: [] };
  }
  const requiredModeIds = collection.modes.map(m => m.modeId);
  const missingModeIds: string[] = [];
  for (const modeId of requiredModeIds) {
    const concrete = resolveToConcrete(catalog, variable.valuesByMode[modeId], 0);
    if (!concrete) missingModeIds.push(modeId);
  }
  return {
    ready: missingModeIds.length === 0,
    collectionId: variable.collectionId,
    requiredModeIds,
    missingModeIds,
  };
}
