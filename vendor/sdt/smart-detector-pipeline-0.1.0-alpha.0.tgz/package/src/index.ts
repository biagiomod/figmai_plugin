export { detectElements } from "./pipeline.js";
export type { FigmaNode, DetectionOptions } from "./pipeline.js";

export { auditDesignTokens } from "./pipeline.js";
export type { TokenAuditOptions } from "./pipeline.js";

// Re-export core output types so consumers import from one place.
export type { DetectionTree, DetectionNode, DetectionSummary, DetectionDraft } from "@smart-detector/schema";
export type { CertaintyLevel, SourceKind } from "@smart-detector/schema";
export type { ReviewState } from "@smart-detector/schema";
export type { TaxonomyEntryName, TaxonomyCategory } from "@smart-detector/schema";

// Token audit DTOs.
export type {
  VariableResolvedType,
  VariableCatalogSnapshot,
  VariableCollectionInfo,
  VariableInfo,
  VariableValue,
  FindingKind,
  FindingSeverity,
  TokenAuditFinding,
  SuggestedVariable,
  ModeCoverage,
  FixIntentKind,
  FixIntent,
  TokenAuditReport,
  TokenAuditSummary,
} from "@smart-detector/schema";
