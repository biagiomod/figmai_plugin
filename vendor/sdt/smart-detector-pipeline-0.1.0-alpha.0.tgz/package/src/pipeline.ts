import { traverseFigmaNode } from "@smart-detector/detector-figma";
import { normalize } from "@smart-detector/normalizer";
import { score } from "@smart-detector/scorer";
import { review } from "@smart-detector/reviewer";
import { buildTaxonomyLookup } from "@smart-detector/taxonomy-bridge";
import type { DetectionTree } from "@smart-detector/schema";

/**
 * A Figma node JSON object from the plugin API or the Figma REST API.
 * Must have at minimum `id` (string) and `type` (string).
 * All other fields are optional and extracted defensively by the traverser.
 */
export type FigmaNode = Record<string, unknown>;

/**
 * Options for the detectElements pipeline.
 */
export interface DetectionOptions {
  /**
   * Override the `sourceRef` field in the output DetectionTree.
   * Defaults to the root node's Figma id.
   */
  sourceRef?: string;
}

/**
 * Run the full Smart Detector pipeline on a Figma node JSON object.
 *
 * Stages: traverseFigmaNode → normalize → score → review
 *
 * The function is declared async to accommodate future async taxonomy lookups.
 * Currently executes synchronously and the returned Promise resolves immediately.
 *
 * @param figmaNode  Root Figma node from plugin or REST API.
 * @param options    Optional overrides.
 * @returns          A fully classified DetectionTree.
 *
 * @throws {Error} If `figmaNode` is null, not an object, or missing a string `id`.
 */
export async function detectElements(
  figmaNode: FigmaNode,
  options: DetectionOptions = {}
): Promise<DetectionTree> {
  const lookup = buildTaxonomyLookup();
  const rawNode = traverseFigmaNode(figmaNode);
  const draft = normalize(rawNode, lookup);
  const scored = score(draft);
  const tree = review(scored);
  if (options.sourceRef !== undefined) {
    return { ...tree, sourceRef: options.sourceRef };
  }
  return tree;
}
