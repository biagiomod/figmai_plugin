import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { detectElements } from "./pipeline.ts";
import type { DetectionNode } from "@smart-detector/schema";

const fixture = {
  id: "1:1",
  name: "Card",
  type: "FRAME",
  x: 0, y: 0, width: 320, height: 200,
  fills: [{ type: "SOLID", color: { r: 1, g: 1, b: 1, a: 1 } }],
  children: [
    {
      id: "1:2",
      name: "Heading",
      type: "TEXT",
      x: 16, y: 16, width: 288, height: 32,
      fills: [{ type: "SOLID", color: { r: 0, g: 0, b: 0, a: 1 } }],
      characters: "Welcome",
      style: { fontSize: 24, fontWeight: 700 },
      children: [],
    },
    {
      id: "1:3",
      name: "Submit",
      type: "FRAME",
      x: 16, y: 152, width: 120, height: 40,
      fills: [{ type: "SOLID", color: { r: 0.2, g: 0.5, b: 1, a: 1 } }],
      children: [
        {
          id: "1:4",
          name: "Submit",
          type: "TEXT",
          x: 24, y: 160, width: 104, height: 24,
          fills: [{ type: "SOLID", color: { r: 1, g: 1, b: 1, a: 1 } }],
          characters: "Submit",
          style: { fontSize: 14, fontWeight: 600 },
          children: [],
        },
      ],
    },
  ],
};

// Recursively walk a DetectionNode tree and collect all nodes.
function collectNodes(node: DetectionNode): DetectionNode[] {
  return [node, ...node.children.flatMap(collectNodes)];
}

const VALID_REVIEW_STATES = new Set(["accepted", "needs-review", "unresolved"]);
const VALID_CERTAINTY_LEVELS = new Set(["exact", "inferred", "weak", "unknown"]);

describe("detectElements (pipeline e2e)", () => {
  it("returns a DetectionTree with version: '1'", async () => {
    const tree = await detectElements(fixture);
    assert.equal(tree.version, "1");
  });

  it("sets sourceType to 'figma'", async () => {
    const tree = await detectElements(fixture);
    assert.equal(tree.sourceType, "figma");
  });

  it("sets sourceRef to the root node id by default", async () => {
    const tree = await detectElements(fixture);
    assert.equal(tree.sourceRef, "1:1");
  });

  it("options.sourceRef overrides sourceRef", async () => {
    const tree = await detectElements(fixture, { sourceRef: "custom-ref" });
    assert.equal(tree.sourceRef, "custom-ref");
  });

  it("root node id matches fixture", async () => {
    const tree = await detectElements(fixture);
    assert.equal(tree.root.id, "1:1");
  });

  it("root node has expected number of children (2)", async () => {
    const tree = await detectElements(fixture);
    assert.equal(tree.root.children.length, 2);
  });

  it("every node has a non-empty rationale", async () => {
    const tree = await detectElements(fixture);
    const nodes = collectNodes(tree.root);
    for (const node of nodes) {
      assert.ok(
        typeof node.rationale === "string" && node.rationale.trim().length > 0,
        `Node ${node.id} has empty or missing rationale`
      );
    }
  });

  it("every node has a valid reviewState", async () => {
    const tree = await detectElements(fixture);
    const nodes = collectNodes(tree.root);
    for (const node of nodes) {
      assert.ok(
        VALID_REVIEW_STATES.has(node.reviewState),
        `Node ${node.id} has invalid reviewState: "${node.reviewState}"`
      );
    }
  });

  it("every node has a valid certainty", async () => {
    const tree = await detectElements(fixture);
    const nodes = collectNodes(tree.root);
    for (const node of nodes) {
      assert.ok(
        VALID_CERTAINTY_LEVELS.has(node.certainty),
        `Node ${node.id} has invalid certainty: "${node.certainty}"`
      );
    }
  });

  it("summary.total equals the total recursive node count", async () => {
    const tree = await detectElements(fixture);
    const nodes = collectNodes(tree.root);
    assert.equal(tree.summary.total, nodes.length);
  });

  it("summary accepted + needsReview + unresolved === summary.total", async () => {
    const tree = await detectElements(fixture);
    const { accepted, needsReview, unresolved, total } = tree.summary;
    assert.equal(accepted + needsReview + unresolved, total);
  });

  it("throws on null input (matches /Invalid Figma node/)", async () => {
    await assert.rejects(
      () => detectElements(null as unknown as Record<string, unknown>),
      /Invalid Figma node/i
    );
  });

  it("throws on non-object input (matches /Invalid Figma node/)", async () => {
    await assert.rejects(
      () => detectElements(42 as unknown as Record<string, unknown>),
      /Invalid Figma node/i
    );
  });
});
